#
# Example file for HelloWorld
#


def main():
    print ("Hello world")
    name = input("What is your name? ")
    print (name, "you are awesome")


if __name__ == "__main__":
    main()