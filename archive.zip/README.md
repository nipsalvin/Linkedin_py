# Linkedin_py
Overview of the Linkedin python course
